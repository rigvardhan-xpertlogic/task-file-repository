from django.contrib import admin
from logoslider.models import Logoslider,first_card_block,second_card_block,twitter_block

class logoslideAdmin(admin.ModelAdmin):
    fields=('position','logo_title','url_of_logo','show_logo','created_at','modified_at')  # list of input data fields
    list_display=('position','logo_title','url_of_logo','show_logo','created_at','modified_at') # data display list
    readonly_fields=['show_logo','created_at','modified_at'] #  fields can not be chane during updation to make it list use [] this brakets.

admin.site.register(Logoslider,logoslideAdmin)

class first_card_blockAdmin(admin.ModelAdmin):
    fields=('position','card_title','url_of_image','image_title','show_image','card_content','link_title','created_at','modified_at') # list of input data fields
    list_display=('position','card_title','url_of_image','image_title','show_image','card_content','link_title','created_at','modified_at') # data display list    
    readonly_fields=['show_image','created_at','modified_at'] #  fields can not be chane during updation to make it list use [] this brakets.

admin.site.register(first_card_block,first_card_blockAdmin)

class second_card_blockAdmin(admin.ModelAdmin):
    fields=('position','card_title','url_of_image','image_title','show_image','card_content','link_title','created_at','modified_at') # list of input data fields
    list_display=('position','card_title','url_of_image','image_title','show_image','card_content','link_title','created_at','modified_at') # data display list
    readonly_fields=['show_image','created_at','modified_at'] #  fields can not be chane during updation to make it list use [] this brakets.

admin.site.register(second_card_block,second_card_blockAdmin)

class twitter_blockAdmin(admin.ModelAdmin):
    fields=('position','url_of_profile_image_top','profile_image_top','profile_name_top','profile_id_top','tweet_top','created_at','modified_at','url_of_profile_image_bottom','profile_image_bottom','profile_name_bottom','profile_id_bottom','tweet_bottom') # list of input data fields
    list_display=('position','url_of_profile_image_top','profile_image_top','profile_name_top','profile_id_top','tweet_top','created_at','modified_at','url_of_profile_image_bottom','profile_image_bottom','profile_name_bottom','profile_id_bottom','tweet_bottom') # data display list
    readonly_fields=['profile_image_top','created_at','modified_at','profile_image_bottom']

admin.site.register(twitter_block,twitter_blockAdmin)
# Register your models here.
