from django.contrib import admin
from logoslider.models import Logoslider,first_card_block,second_card_block,twitter_block,first_div,top_card_block,first_div_list,single_heading,div_2_content,div_3_content,footer_list_heading,footer_list_item

class logoslideAdmin(admin.ModelAdmin):
    fields=('position','logo_title','url_of_logo','show_logo','created_at','modified_at')  # list of input data fields
    list_display=('position','logo_title','url_of_logo','show_logo','created_at','modified_at') # data display list
    readonly_fields=['show_logo','created_at','modified_at'] #  fields can not be chane during updation to make it list use [] this brakets.

admin.site.register(Logoslider,logoslideAdmin)

class first_card_blockAdmin(admin.ModelAdmin):
    fields=('position','card_title','url_of_image','image_title','show_image','card_content','link_title','created_at','modified_at') # list of input data fields
    list_display=('position','card_title','url_of_image','image_title','show_image','card_content','link_title','created_at','modified_at') # data display list    
    readonly_fields=['show_image','created_at','modified_at'] #  fields can not be chane during updation to make it list use [] this brakets.

admin.site.register(first_card_block,first_card_blockAdmin)

class second_card_blockAdmin(admin.ModelAdmin):
    fields=('position','card_title','url_of_image','image_title','show_image','card_content','link_title','created_at','modified_at') # list of input data fields
    list_display=('position','card_title','url_of_image','image_title','show_image','card_content','link_title','created_at','modified_at') # data display list
    readonly_fields=['show_image','created_at','modified_at'] #  fields can not be chane during updation to make it list use [] this brakets.

admin.site.register(second_card_block,second_card_blockAdmin)

class twitter_blockAdmin(admin.ModelAdmin):
    fields=('position','url_of_profile_image_top','profile_image_top','profile_name_top','profile_id_top','tweet_top','created_at','modified_at','url_of_profile_image_bottom','profile_image_bottom','profile_name_bottom','profile_id_bottom','tweet_bottom') # list of input data fields
    list_display=('position','url_of_profile_image_top','profile_image_top','profile_name_top','profile_id_top','tweet_top','created_at','modified_at','url_of_profile_image_bottom','profile_image_bottom','profile_name_bottom','profile_id_bottom','tweet_bottom') # data display list
    readonly_fields=['profile_image_top','created_at','modified_at','profile_image_bottom']

admin.site.register(twitter_block,twitter_blockAdmin)
#--------------------------------------------------------
class first_divAdmin(admin.ModelAdmin):
    fields=('heading_for','heading','content','created_at','modified_at')
    list_display=('heading_for','heading','content','created_at','modified_at')
    readonly_fields=['created_at','modified_at']
admin.site.register(first_div,first_divAdmin)

class first_div_listAdmin(admin.ModelAdmin):
    fields=('position','bold_text','normal_text','created_at','modified_at')
    list_display=('position','bold_text','normal_text','created_at','modified_at')
    readonly_fields=['created_at','modified_at']

admin.site.register(first_div_list,first_div_listAdmin)
#-----------------------------------------------------------

class top_card_blockAdmin(admin.ModelAdmin):
    fields=('card_title','link_title','url_of_image','show_image','url_of_backgroundimage','show_backgroundimage','created_at','modified_at')
    list_display=('card_title','link_title','url_of_image','show_image','url_of_backgroundimage','show_backgroundimage','created_at','modified_at')
    readonly_fields=['show_image','show_backgroundimage','created_at','modified_at']
admin.site.register(top_card_block,top_card_blockAdmin)


class single_headingAdmin(admin.ModelAdmin):
    fields=('heading_for','heading','created_at','modified_at')
    list_display=('heading_for','heading','created_at','modified_at')
    readonly_fields=['created_at','modified_at']
admin.site.register(single_heading,single_headingAdmin)

class div_2_contentAdmin(admin.ModelAdmin):
    fields=('position','heading','paragraph','link_heading','created_at','modified_at')
    list_display=('position','heading','paragraph','link_heading','created_at','modified_at')
    readonly_fields=['created_at','modified_at']
admin.site.register(div_2_content,div_2_contentAdmin)

class div_3_contentAdmin(admin.ModelAdmin):
    fields=('position','heading','paragraph','link_heading','created_at','modified_at')
    list_display=('position','heading','paragraph','link_heading')
    readonly_fields=['created_at','modified_at']
admin.site.register(div_3_content,div_3_contentAdmin)

class footer_list_headingsAdmin(admin.ModelAdmin):
    fields=('heading_for','heading','created_at','modified_at')
    list_display=('heading_for','heading','created_at','modified_at')
    readonly_fields=['created_at','modified_at']
admin.site.register(footer_list_heading,footer_list_headingsAdmin)

class footer_list_itemAdmin(admin.ModelAdmin):
    fields=('item_of','list_item','position','created_at','modified_at')
    list_display=('item_of','list_item','position','created_at','modified_at')
    readonly_fields=['created_at','modified_at']
admin.site.register(footer_list_item,footer_list_itemAdmin)

# Register your models here.