# This file is need to be created for api(json formate)
from rest_framework import serializers
# import models from app
from logoslider.models import Logoslider,first_card_block,second_card_block,twitter_block,first_div,top_card_block,first_div_list,single_heading,div_2_content,div_3_content,footer_list_heading,footer_list_item


# create serializer
class Logoslider_ser(serializers.HyperlinkedModelSerializer):
    id=serializers.ReadOnlyField()
    class Meta:
        model=Logoslider
        fields="__all__"

class first_card_block_ser(serializers.HyperlinkedModelSerializer):
    id=serializers.ReadOnlyField()
    class Meta:
        model=first_card_block
        fields="__all__"

class second_card_block_ser(serializers.HyperlinkedModelSerializer):
    id=serializers.ReadOnlyField()
    class Meta:
        model=second_card_block
        fields="__all__"

class twitter_block_ser(serializers.HyperlinkedModelSerializer):
    id=serializers.ReadOnlyField()
    class Meta:
        model=twitter_block
        fields="__all__"

class first_div_ser(serializers.HyperlinkedModelSerializer):
    id=serializers.ReadOnlyField()
    class Meta:
        model=first_div
        fields="__all__"

class top_card_block_ser(serializers.HyperlinkedModelSerializer):
    id=serializers.ReadOnlyField()
    class Meta:
        model=top_card_block
        fields="__all__"

class first_div_list_ser(serializers.HyperlinkedModelSerializer):
    id=serializers.ReadOnlyField()
    class Meta:
        model=first_div_list
        fields="__all__"

class single_heading_ser(serializers.HyperlinkedModelSerializer):
    id=serializers.ReadOnlyField()
    class Meta:
        model=single_heading
        fields="__all__"

class div_2_content_ser(serializers.HyperlinkedModelSerializer):
    id=serializers.ReadOnlyField()
    class Meta:
        model=div_2_content
        fields="__all__"

class div_3_content_ser(serializers.HyperlinkedModelSerializer):
    id=serializers.ReadOnlyField()
    class Meta:
        model=div_3_content
        fields="__all__"


class footer_list_item_ser(serializers.HyperlinkedModelSerializer):
    id=serializers.ReadOnlyField()
    class Meta:
        model=footer_list_item
        fields="__all__"

class footer_list_heading_ser(serializers.HyperlinkedModelSerializer):
    id=serializers.ReadOnlyField()
    list_item=footer_list_item_ser(many=True,read_only=True)
    class Meta:
        model=footer_list_heading
        fields=['id','heading_for','heading','list_item']










#class _ser(serializers.HyperlinkedModelSerializer):
#    id=serializers.ReadOnlyField()
#    class Meta:
#        model=
#        fields="__all__"
#
