from django.shortcuts import render
from rest_framework import viewsets
from logoslider.models import Logoslider,first_card_block,second_card_block,twitter_block,first_div,top_card_block,first_div_list,single_heading,div_2_content,div_3_content,footer_list_heading,footer_list_item
from logoslider.serializers import Logoslider_ser,first_card_block_ser,second_card_block_ser,twitter_block_ser,first_div_ser,top_card_block_ser,first_div_list_ser,single_heading_ser,div_2_content_ser,div_3_content_ser,footer_list_heading_ser,footer_list_item_ser


# Create your views here.
class Logoslider_data(viewsets.ModelViewSet):
    queryset=Logoslider.objects.all().order_by('position')
    serializer_class=Logoslider_ser


class  first_card_block_data(viewsets.ModelViewSet):
    queryset= first_card_block.objects.all().order_by('position')
    serializer_class= first_card_block_ser
    
class  second_card_block_data(viewsets.ModelViewSet):
    queryset= second_card_block.objects.all().order_by('position')
    serializer_class= second_card_block_ser

class  twitter_block_data(viewsets.ModelViewSet):
    queryset= twitter_block.objects.all().order_by('position')
    serializer_class= twitter_block_ser

class  first_div_data(viewsets.ModelViewSet):
    queryset= first_div.objects.all()
    serializer_class= first_div_ser
    
class  top_card_block_data(viewsets.ModelViewSet):
    queryset= top_card_block.objects.all()
    serializer_class= top_card_block_ser
    
class  first_div_list_data(viewsets.ModelViewSet):
    queryset= first_div_list.objects.all().order_by('position')
    serializer_class= first_div_list_ser

class  single_heading_data(viewsets.ModelViewSet):
    queryset= single_heading.objects.all().order_by('heading_for')
    serializer_class= single_heading_ser
    
class  div_2_content_data(viewsets.ModelViewSet):
    queryset= div_2_content.objects.all().order_by('position')
    serializer_class= div_2_content_ser
   
class  div_3_content_data(viewsets.ModelViewSet):
    queryset= div_3_content.objects.all().order_by('position')
    serializer_class= div_3_content_ser

class  footer_list_heading_data(viewsets.ModelViewSet):
    queryset= footer_list_heading.objects.all().order_by('heading_for')
    serializer_class= footer_list_heading_ser

class  footer_list_item_data(viewsets.ModelViewSet):
    queryset= footer_list_item.objects.all().all().order_by('item_of')        
    serializer_class= footer_list_item_ser

#class  _data(viewsets.ModelViewSet):
#    queryset= .objects.all()
#    serializer_class= _ser
#