from django.db import models

from autoslug import AutoSlugField
from django.utils.html import format_html

from django.core.validators import MinValueValidator, MaxValueValidator

class Logoslider(models.Model):
    position=models.BigIntegerField(primary_key=False,unique=True,default=False,null=True,serialize=True)
    logo_title=models.CharField(max_length=60)
    url_of_logo=models.FileField(upload_to="logo_slide/",max_length=250,null=True,default=None)
    slug = AutoSlugField(populate_from='logo_title',unique=True,null=True,default=None)
    modified_at=models.DateTimeField(auto_now=True)
    created_at=models.DateTimeField(auto_now_add=True)
    class Meta:
        ordering=['-position']
    def show_logo(self):
        return format_html('<img src="{}"width="100" height="50">'.format(self.url_of_logo.url))
    show_logo.short_description ='show logo'
    show_logo.allow_tags=True


class first_div(models.Model):
    #limit=models.PositiveIntegerField(default=1,unique=True,null=False)
    HEADINGLIMIT=(
        ('div_1','DIV_1'),
    )
    heading_for=models.CharField(max_length=8,unique=True,choices=HEADINGLIMIT,default="DIV_1",null=False)
    heading=models.CharField(max_length=35,null=False,default=None)
    content=models.CharField(max_length=70,null=False,default=None)
    modified_at=models.DateTimeField(auto_now=True)
    created_at=models.DateTimeField(auto_now_add=True)


class first_div_list(models.Model):
    position=models.BigIntegerField(primary_key=False,unique=True,default=False,null=False,serialize=True)
    bold_text=models.CharField(max_length=20,unique=True,null=False,default=None)
    normal_text=models.CharField(max_length=40,null=False,default=None)
    modified_at=models.DateTimeField(auto_now=True)
    created_at=models.DateTimeField(auto_now_add=True)
    class Meta:
        ordering=['-position']

class first_card_block(models.Model):
    position=models.BigIntegerField(primary_key=False,unique=True,default=False,null=True,serialize=True)
    card_title=models.CharField(max_length=25)
    url_of_image=models.FileField(upload_to="first_card_block_img/",max_length=250,null=True,default=None)
    image_title=models.CharField(max_length=60)
    card_content=models.CharField(max_length=50)
    link_title=models.CharField(max_length=24)
    modified_at=models.DateTimeField(auto_now=True)
    created_at=models.DateTimeField(auto_now_add=True)
    class Meta:
        ordering=['-position']


    def show_image(self):
        return format_html('<img src="{}"width="200" height="150">'.format(self.url_of_image.url))
    show_image.short_description ='show image'
    show_image.allow_tags=True

class second_card_block(models.Model):
    position=models.BigIntegerField(primary_key=False,unique=True,default=False,null=True,serialize=True)
    card_title=models.CharField(max_length=40)
    url_of_image=models.FileField(upload_to="second_card_block_img/",max_length=250,null=True,default=None)
    image_title=models.CharField(max_length=60)
    card_content=models.CharField(max_length=400)
    link_title=models.CharField(max_length=30)
    modified_at=models.DateTimeField(auto_now=True)
    created_at=models.DateTimeField(auto_now_add=True)
    class Meta:
        ordering=['-position']

    def show_image(self):
        return format_html('<img src="{}"width="200" height="150">'.format(self.url_of_image.url))
    show_image.short_description ='show image'
    show_image.allow_tags=True

class twitter_block(models.Model):
    position=models.BigIntegerField(primary_key=False,unique=True,default=False,null=True,serialize=True)
    url_of_profile_image_top=models.FileField(upload_to="second_card_block/top_img/",max_length=250,null=True,default=None)
    profile_name_top=models.CharField(max_length=20,null=True)
    profile_id_top=models.CharField(max_length=20,unique=True,null=True)
    tweet_top=models.TextField(max_length=280,null=True)
    url_of_profile_image_bottom=models.FileField(upload_to="second_card_block/bottom_img/",max_length=250,null=True,default=None)
    profile_name_bottom=models.CharField(max_length=20,null=True)
    profile_id_bottom=models.CharField(max_length=20,unique=True,null=True)
    tweet_bottom=models.TextField(max_length=280,null=True)
    modified_at=models.DateTimeField(auto_now=True)
    created_at=models.DateTimeField(auto_now_add=True)
    class Meta:
        ordering=['-position']

    def profile_image_top(self):
        return format_html('<img src="{}"width="32" height="32">'.format(self.url_of_profile_image_top.url))
    profile_image_top.short_description ='profile image top'
    profile_image_top.allow_tags=True

    def profile_image_bottom(self):
        return format_html('<img src="{}"width="32" height="32">'.format(self.url_of_profile_image_bottom.url))
    profile_image_bottom.short_description ='profile image bottom'
    profile_image_bottom.allow_tags=True

class top_card_block(models.Model):
    limit=models.PositiveIntegerField(default=1,unique=True,null=False)
    url_of_image=models.FileField(upload_to="top_card_block_img/",max_length=250,null=False,default=False)
    url_of_backgroundimage=models.FileField(upload_to="top_card_block_backgroundimg/",max_length=250,null=False,default=False)
    card_title=models.CharField(max_length=100)
    link_title=models.CharField(max_length=35)
    created_at=models.DateTimeField(auto_now_add=True)
    modified_at=models.DateTimeField(auto_now=True)
    
    def show_backgroundimage(self):
        return format_html('<img src="{}"width="300" height="400">'.format(self.url_of_backgroundimage.url))
    show_backgroundimage.short_description ='show background image'
    show_backgroundimage.allow_tags=True

    def show_image(self):
        return format_html('<img src="{}"width="200" height="300">'.format(self.url_of_image.url))
    show_image.short_description ='show image'
    show_image.allow_tags=True

class single_heading(models.Model):
    HEADING_CHOICES = (
    ('div_2','DIV_2'),
    ('div_3','DIV_3'),
    ('div_4','DIV_4'),
    )
    heading_for=models.CharField(max_length=8,unique=True,choices=HEADING_CHOICES,default=None,null=False)
    heading=models.CharField(max_length=40,default=None,null=False,unique=True)
    modified_at=models.DateTimeField(auto_now=True)
    created_at=models.DateTimeField(auto_now_add=True)
    class Meta:
        ordering=['-heading_for']

class div_2_content(models.Model):
    position=models.IntegerField(default=None,unique=True,null=False,validators=[MinValueValidator(1),MaxValueValidator(2)])
    heading=models.CharField(max_length=40,default=None,null=False,unique=True)
    paragraph=models.TextField(max_length=150,default=None,null=False,unique=True)
    link_heading=models.CharField(max_length=20,default=None,null=False,unique=True)
    modified_at=models.DateTimeField(auto_now=True)
    created_at=models.DateTimeField(auto_now_add=True)
    class Meta:
        ordering=['-position']

class div_3_content(models.Model):
    position=models.IntegerField(default=None,unique=True,null=False,validators=[MinValueValidator(1),MaxValueValidator(3)])
    heading=models.CharField(max_length=40,default=None,null=False,unique=True)
    paragraph=models.TextField(max_length=150,default=None,null=False,unique=True)
    link_heading=models.CharField(max_length=20,default=None,null=False,unique=True)
    modified_at=models.DateTimeField(auto_now=True)
    created_at=models.DateTimeField(auto_now_add=True)
    class Meta:
        ordering=['-position']

class footer_list_heading(models.Model):
    HEADING_CHOICES = (
    ('list_1','LIST_1'),
    ('list_2','LIST_2'),
    ('list_3','LIST_3'),
    ('list_4','LIST_4'),
    ('list_5','LIST_5'),
    )
    heading_for=models.CharField(max_length=8,unique=True,choices=HEADING_CHOICES,default=None,null=False)
    heading=models.CharField(max_length=40,default=None,null=False,unique=True)
    modified_at=models.DateTimeField(auto_now=True)
    created_at=models.DateTimeField(auto_now_add=True)
    
    def __str__(self) :
        return self.heading
    
    class Meta:
        ordering=['heading_for']

class footer_list_item(models.Model):
    position=models.PositiveIntegerField(default=None,unique=False,null=False,validators=[MinValueValidator(1),MaxValueValidator(40)])
    list_item=models.CharField(max_length=40,default=None,null=False,unique=True)
    item_of=models.ForeignKey("footer_list_heading",on_delete=models.CASCADE,related_name="list_item")
    modified_at=models.DateTimeField(auto_now=True)
    created_at=models.DateTimeField(auto_now_add=True)
    
    def __str__(self) :
        return self.list_item
    
    class Meta:
        ordering=['item_of','position']
        unique_together = (('position', 'item_of'),)

    #url=models.URLField(_(""), max_length=200)



# Create your models here.

