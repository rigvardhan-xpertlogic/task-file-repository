from django.db import models

from autoslug import AutoSlugField
from django.utils.html import format_html


class Logoslider(models.Model):
    position=models.BigIntegerField(primary_key=False,unique=True,default=False,null=True,serialize=True)
    logo_title=models.CharField(max_length=60)
    url_of_logo=models.FileField(upload_to="logo_slide/",max_length=250,null=True,default=None)
    slug = AutoSlugField(populate_from='logo_title',unique=True,null=True,default=None)
    modified_at=models.DateTimeField(auto_now=True)
    created_at=models.DateTimeField(auto_now_add=True)

    def show_logo(self):
        return format_html('<img src="{}"width="100" height="50">'.format(self.url_of_logo.url))
    show_logo.short_description ='show logo'
    show_logo.allow_tags=True

#===========================================================================================
#STATUS = (
#    ('display','DISPLAY'),
#    ('hide','HIDE')
#)
#class top_card_block(models.Model):
#    status=models.CharField(unique=True,choices=STATUS,default='hide',null=False)
#    url_of_image=models.FileField(upload_to="top_card_block_img/",max_length=250,null=True,default=False)
#    image_title=models.CharField(max_length=60)
#    card_title=models.CharField(max_length=100)
#    link_title=models.CharField(max_length=35)
#    created_at=models.DateTimeField(auto_now_add=True)
#    modified_at=models.DateTimeField(auto_now=True)
#    def show_image(self):
#        return format_html('<img src="{}"width="200" height="150">'.format(self.url_of_image.url))
#    show_image.short_description ='show image'
#    show_image.allow_tags=True








class first_card_block(models.Model):
    position=models.BigIntegerField(primary_key=False,unique=True,default=False,null=True,serialize=True)
    card_title=models.CharField(max_length=25)
    url_of_image=models.FileField(upload_to="first_card_block_img/",max_length=250,null=True,default=None)
    image_title=models.CharField(max_length=60)
    card_content=models.CharField(max_length=50)
    link_title=models.CharField(max_length=24)
    modified_at=models.DateTimeField(auto_now=True)
    created_at=models.DateTimeField(auto_now_add=True)
    def show_image(self):
        return format_html('<img src="{}"width="200" height="150">'.format(self.url_of_image.url))
    show_image.short_description ='show image'
    show_image.allow_tags=True

class second_card_block(models.Model):
    position=models.BigIntegerField(primary_key=False,unique=True,default=False,null=True,serialize=True)
    card_title=models.CharField(max_length=40)
    url_of_image=models.FileField(upload_to="second_card_block_img/",max_length=250,null=True,default=None)
    image_title=models.CharField(max_length=60)
    card_content=models.CharField(max_length=400)
    link_title=models.CharField(max_length=30)
    modified_at=models.DateTimeField(auto_now=True)
    created_at=models.DateTimeField(auto_now_add=True)

    def show_image(self):
        return format_html('<img src="{}"width="200" height="150">'.format(self.url_of_image.url))
    show_image.short_description ='show image'
    show_image.allow_tags=True

class twitter_block(models.Model):
    position=models.BigIntegerField(primary_key=False,unique=True,default=False,null=True,serialize=True)
    url_of_profile_image_top=models.FileField(upload_to="second_card_block/top_img/",max_length=250,null=True,default=None)
    profile_name_top=models.CharField(max_length=20,null=True)
    profile_id_top=models.CharField(max_length=20,unique=True,null=True)
    tweet_top=models.TextField(max_length=280,null=True)
    url_of_profile_image_bottom=models.FileField(upload_to="second_card_block/bottom_img/",max_length=250,null=True,default=None)
    profile_name_bottom=models.CharField(max_length=20,null=True)
    profile_id_bottom=models.CharField(max_length=20,unique=True,null=True)
    tweet_bottom=models.TextField(max_length=280,null=True)
    modified_at=models.DateTimeField(auto_now=True)
    created_at=models.DateTimeField(auto_now_add=True)

    def profile_image_top(self):
        return format_html('<img src="{}"width="32" height="32">'.format(self.url_of_profile_image_top.url))
    profile_image_top.short_description ='profile image top'
    profile_image_top.allow_tags=True

    def profile_image_bottom(self):
        return format_html('<img src="{}"width="32" height="32">'.format(self.url_of_profile_image_bottom.url))
    profile_image_bottom.short_description ='profile image bottom'
    profile_image_bottom.allow_tags=True
# Create your models here.
