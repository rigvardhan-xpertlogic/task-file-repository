from django.contrib import admin
from django.urls import path,include

from rest_framework import routers
from logoslider.views import Logoslider_data,first_card_block_data,second_card_block_data,twitter_block_data,first_div_data,top_card_block_data,first_div_list_data,single_heading_data,div_2_content_data,div_3_content_data,footer_list_heading_data,footer_list_item_data

router=routers.DefaultRouter()
router.register(r'Logoslider',Logoslider_data),
router.register(r'first_card_block',first_card_block_data),
router.register(r'second_card_block',second_card_block_data),
router.register(r'twitter_block',twitter_block_data),
router.register(r'first_div',first_div_data),
router.register(r'top_card_block',top_card_block_data),
router.register(r'first_div_list',first_div_list_data),
router.register(r'single_heading',single_heading_data),
router.register(r'div_2_content',div_2_content_data),
router.register(r'div_3_content', div_3_content_data),
router.register(r'footer_list_heading', footer_list_heading_data),
router.register(r'footer_list_item', footer_list_item_data),
#router.register(r'', _data)
urlpatterns = [
        path('',include(router.urls))
]