from django.shortcuts import render

from logoslider.models import Logoslider,first_card_block,second_card_block,twitter_block,first_div,top_card_block,first_div_list,single_heading,div_2_content,div_3_content,footer_list_heading,footer_list_item


def indexpage(request):
    logosliderData=Logoslider.objects.all().order_by('position')
    first_card_blockData=first_card_block.objects.all().order_by('position')
    second_card_blockData=second_card_block.objects.all().order_by('position')
    twitter_blockData=twitter_block.objects.all().order_by('position')
    first_divData=first_div.objects.all()[0]
    first_div_listData= first_div_list.objects.all().order_by('position')
    top_card_blockdata=top_card_block.objects.all()[0]
    div_2_heading=single_heading.objects.filter(heading_for="div_2")[0]
    div_3_heading=single_heading.objects.filter(heading_for="div_3")[0]
    div_4_heading=single_heading.objects.filter(heading_for="div_4")[0]
    div_2_contentData=div_2_content.objects.all().order_by('position')
    div_3_contentData=div_3_content.objects.all().order_by('position')
    footer_list_headings=footer_list_heading.objects.all().order_by('heading_for')
    footer_list_items=footer_list_item.objects.all().order_by('item_of','position')
    data={
        'logosliderData':logosliderData,
        'first_card_blockData':first_card_blockData,
        'second_card_blockData':second_card_blockData,
        'twitter_blockData':twitter_blockData,
        'firstdiv_Data':first_divData,
        'first_listData':first_div_listData,
        'signal_card_Data':top_card_blockdata,
        'div_2_heading':div_2_heading,
        'div_3_heading':div_3_heading,
        'div_4_heading':div_4_heading,
        'div_2_content':div_2_contentData,
        'div_3_content':div_3_contentData,
        'footer_list_heading':footer_list_headings,
        'footer_list_item':footer_list_items,
    }
    return render(request,"index.html",data)
