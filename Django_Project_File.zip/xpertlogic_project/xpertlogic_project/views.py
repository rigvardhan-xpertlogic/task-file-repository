from django.shortcuts import render

from logoslider.models import Logoslider,first_card_block,second_card_block,twitter_block

def homepage(request):
    logosliderData=Logoslider.objects.all().order_by('position')
    first_card_blockData=first_card_block.objects.all().order_by('position')
    second_card_blockData=second_card_block.objects.all().order_by('position')
    twitter_blockData=twitter_block.objects.all().order_by('position')
    data={
        'logosliderData':logosliderData,
        'first_card_blockData':first_card_blockData,
        'second_card_blockData':second_card_blockData,
        'twitter_blockData':twitter_blockData,
    }
    return render(request,"index.html",data)
